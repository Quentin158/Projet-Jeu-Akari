package iut.prj2024.view;

import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;
import iut.prj2024.AkariApp;
import javafx.beans.binding.Bindings;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.geometry.Insets;
import javafx.scene.Node;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.control.RadioMenuItem;
import javafx.scene.input.MouseButton;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.scene.media.AudioClip;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;
import iut.prj2024.jeu.Cellule;
import iut.prj2024.jeu.JeuAraki;
import iut.prj2024.jeu.TypeCellule;

public class AkariAppController implements Initializable {
    private AkariApp app;

    // Annotations FXML pour lier avec le fichier LandingPage.fxml
    @FXML private VBox vBoxLeft;
    @FXML private Pane paneBottom;
    @FXML private Pane paneRight;
    @FXML private Button playButton;
    @FXML private RadioMenuItem e3x3;
    @FXML private RadioMenuItem e5x5;
    @FXML private RadioMenuItem e6x4V1;
    @FXML private RadioMenuItem e6x4V2;
    @FXML private RadioMenuItem e6x4V3;
    @FXML private RadioMenuItem e7x7;
    @FXML private RadioMenuItem e10x10;
    @FXML private RadioMenuItem e14x14;
    @FXML private RadioMenuItem h5x5;
    @FXML private RadioMenuItem h7x7;
    @FXML private RadioMenuItem h10x10;
    @FXML private RadioMenuItem t5x5;
    @FXML private RadioMenuItem t7x7;
    @FXML private RadioMenuItem t14x14;
    @FXML private BorderPane gameGrid;
    
    @FXML private Label scoreLabel = new Label();
    @FXML private Button nouveauJeu;
    @FXML private Button quitButton;

    private GridPane gridPane;
    private JeuAraki jeuAraki;
    private boolean jeuTermine = false;
    private static int scoreTotal = 0;

    // Référence de l'application
    public void setApp(AkariApp app) {
        this.app = app;
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        this.gridPane = new GridPane();
        setMenuVisibility(true);
        setVBoxVisibility(true);
        setMenuVisibility(true);
    }

    // Définir la visibilité de la Vbox
    private void setVBoxVisibility(boolean isVisible) {
        vBoxLeft.setVisible(isVisible);
        vBoxLeft.setManaged(isVisible); 
    }

    // Définir la visibilité des éléments du menu
    private void setMenuVisibility(boolean isVisible) {
        e3x3.setVisible(isVisible);
        e5x5.setVisible(isVisible);
        e6x4V1.setVisible(isVisible);
        e6x4V2.setVisible(isVisible);
        e6x4V3.setVisible(isVisible);
        e7x7.setVisible(isVisible);
        e10x10.setVisible(isVisible);
        e14x14.setVisible(isVisible);
        h5x5.setVisible(isVisible);
        h7x7.setVisible(isVisible);
        h10x10.setVisible(isVisible);
        t5x5.setVisible(isVisible);
        t7x7.setVisible(isVisible);
        t14x14.setVisible(isVisible);
    }

    // Activation du bouton pour jouer
    @FXML
    public void enablePlayButton() {
        this.playButton.setDisable(false);
    }

    // Génération de la grille de jeu
    public GridPane generateGrid(InputStream pathGrid, GridPane gridPane) throws IOException {
        jeuAraki.chargerGrilleFromStream(pathGrid);
        int x = this.jeuAraki.getLargeur();
        int y = this.jeuAraki.getHauteur();
        Cellule cellule;

        for (int i = 0; i < x; i++) {
            for (int j = 0; j < y; j++) {
                cellule = jeuAraki.getCellule(i, j);
                Pane pane = new Pane();
                pane.setPrefHeight(gameGrid.getHeight() / x);
                pane.setPrefWidth(gameGrid.getWidth() / y);
                final int finalX = i;
                final int finalY = j;
                if (cellule.getType() == TypeCellule.MUR) {
                    pane.setStyle("-fx-background-color: grey");
                    int nombreAmpoulesNecessaires = cellule.getNombreAmpoulesNecessaires();
                    if (nombreAmpoulesNecessaires != -1) {
                        Label nbrAN = new Label(String.valueOf(nombreAmpoulesNecessaires));
                        final Pane paneBis = pane;
                        nbrAN.layoutXProperty().bind(Bindings.createDoubleBinding(() -> (paneBis.getWidth() - nbrAN.getWidth()) / 2,pane.widthProperty(), nbrAN.widthProperty()));
                        nbrAN.layoutYProperty().bind(Bindings.createDoubleBinding(() -> (paneBis.getHeight() - nbrAN.getHeight()) / 2,pane.heightProperty(), nbrAN.heightProperty()));

                        pane.widthProperty().addListener((obs, oldVal, newVal) -> resizeFont(nbrAN, paneBis));
                        pane.heightProperty().addListener((obs, oldVal, newVal) -> resizeFont(nbrAN, paneBis));
                        nbrAN.setStyle("-fx-text-fill: white; -fx-alignment: center;");
                        pane.getChildren().add(nbrAN);
                        int ampoulesAutour = compterAmpoulesAutour(x, y);
                        if (ampoulesAutour > nombreAmpoulesNecessaires || ampoulesAutour < nombreAmpoulesNecessaires) {
                            pane.setStyle("-fx-background-color: red; -fx-text-fill: black;");
                        }
                    }
                } else {
                    updateCellPaneAppearance(finalX, finalY, pane);
                }
                gridPane.add(pane, i, j);
            }
        }

        gridPane.setGridLinesVisible(true);
        return gridPane;
    }

    // Génération de la grille en fonction du choix de l'utilisateur
    @FXML
    public void generateGridFromChoice() throws Exception {
        GridPane gridPane = new GridPane();
        gridPane.setPadding(new Insets(40, 0, 0, 20));
        setMenuVisibility(false);
        setMenuVisibility(false);
        setVBoxVisibility(false);
        if (this.e3x3.isSelected()) {
            this.jeuAraki = new JeuAraki(3, 3);
            try (InputStream inputStream = getClass().getResourceAsStream("/iut/prj2024/jeu/dataset/3x3/easy.txt")){
                this.gridPane = generateGrid(inputStream, gridPane);
            } catch (IOException e) {
                e.printStackTrace();
            }
        } else if (this.e5x5.isSelected()) {
            this.jeuAraki = new JeuAraki(5, 5);
            try (InputStream inputStream = getClass().getResourceAsStream("/iut/prj2024/jeu/dataset/5x5/easy [conflicted].txt")){
                this.gridPane = generateGrid(inputStream, gridPane);
            } catch (IOException e) {
                e.printStackTrace();
            }
        } else if (this.e6x4V1.isSelected()) {
            this.jeuAraki = new JeuAraki(6, 4);
            try (InputStream inputStream = getClass().getResourceAsStream("/iut/prj2024/jeu/dataset/6x4/easy1.txt")){
                this.gridPane = generateGrid(inputStream, gridPane);
            } catch (IOException e) {
                e.printStackTrace();
            }
        } else if (this.e6x4V2.isSelected()) {
            this.jeuAraki = new JeuAraki(6, 4);
            try (InputStream inputStream = getClass().getResourceAsStream("/iut/prj2024/jeu/dataset/6x4/easy2.txt")){
                this.gridPane = generateGrid(inputStream, gridPane);
            } catch (IOException e) {
                e.printStackTrace();
            }
        } else if (this.e6x4V3.isSelected()) {
            this.jeuAraki = new JeuAraki(6, 4);
            try (InputStream inputStream = getClass().getResourceAsStream("/iut/prj2024/jeu/dataset/6x4/easy3.txt")){
                this.gridPane = generateGrid(inputStream, gridPane);
            } catch (IOException e) {
                e.printStackTrace();
            }
        } else if (this.e7x7.isSelected()) {
            this.jeuAraki = new JeuAraki(7, 7);
            try (InputStream inputStream = getClass().getResourceAsStream("/iut/prj2024/jeu/dataset/7x7/easy.txt")){
                this.gridPane = generateGrid(inputStream, gridPane);
            } catch (IOException e) {
                e.printStackTrace();
            }
        } else if (this.e10x10.isSelected()) {
            this.jeuAraki = new JeuAraki(10, 10);
            try (InputStream inputStream = getClass().getResourceAsStream("/iut/prj2024/jeu/dataset/10x10/easy.txt")){
                this.gridPane = generateGrid(inputStream, gridPane);
            } catch (IOException e) {
                e.printStackTrace();
            }
        } else if (this.e14x14.isSelected()) {
            this.jeuAraki = new JeuAraki(14, 14);
            try (InputStream inputStream = getClass().getResourceAsStream("/iut/prj2024/jeu/dataset/14x14/easy.txt")){
                this.gridPane = generateGrid(inputStream, gridPane);
            } catch (IOException e) {
                e.printStackTrace();
            }
        } else if (this.h5x5.isSelected()) {
            this.jeuAraki = new JeuAraki(5, 5);
            try (InputStream inputStream = getClass().getResourceAsStream("/iut/prj2024/jeu/dataset/5x5/hard.txt")){
                this.gridPane = generateGrid(inputStream, gridPane);
            } catch (IOException e) {
                e.printStackTrace();
            }
        } else if (this.h7x7.isSelected()) {
            this.jeuAraki = new JeuAraki(7, 7);
            try (InputStream inputStream = getClass().getResourceAsStream("/iut/prj2024/jeu/dataset/7x7/hard.txt")){
                this.gridPane = generateGrid(inputStream, gridPane);
            } catch (IOException e) {
                e.printStackTrace();
            }
        } else if (this.h10x10.isSelected()) {
            this.jeuAraki = new JeuAraki(10, 10);
            try (InputStream inputStream = getClass().getResourceAsStream("/iut/prj2024/jeu/dataset/10x10/hard.txt")){
                this.gridPane = generateGrid(inputStream, gridPane);
            } catch (IOException e) {
                e.printStackTrace();
            }
        } else if (this.t5x5.isSelected()) {
            this.jeuAraki = new JeuAraki(5, 5);
            try (InputStream inputStream = getClass().getResourceAsStream("/iut/prj2024/jeu/dataset/5x5/tricky.txt")){
                this.gridPane = generateGrid(inputStream, gridPane);
            } catch (IOException e) {
                e.printStackTrace();
            }
        } else if (this.t7x7.isSelected()) {
            this.jeuAraki = new JeuAraki(7, 7);
            try (InputStream inputStream = getClass().getResourceAsStream("/iut/prj2024/jeu/dataset/7x7/tricky.txt")){
                this.gridPane = generateGrid(inputStream, gridPane);
            } catch (IOException e) {
                e.printStackTrace();
            }
        } else if (this.t14x14.isSelected()) {
            this.jeuAraki = new JeuAraki(14, 14);
            try (InputStream inputStream = getClass().getResourceAsStream("/iut/prj2024/jeu/dataset/14x14/tricky.txt")){
                this.gridPane = generateGrid(inputStream, gridPane);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        this.gameGrid.setCenter(gridPane);
        this.quitButton.setVisible(false);
        this.nouveauJeu.setVisible(true);
    }

    // Redimensionne la police d'un label en fonction de la taille du conteneur parent
    private void resizeFont(Label label, Pane pane) {
        double scaleFactor = Math.min(pane.getWidth(), pane.getHeight()) / 3;
        label.setStyle("-fx-font-size: " + scaleFactor + "px; -fx-text-fill: white;");
    }

    // Initialisation des couleurs en fonctions des types des cellules
    private void updateCellPaneAppearance(int x, int y, Pane pane) {
        Cellule cellule = jeuAraki.getCellule(x, y);
        pane.setOnMouseClicked(null);

        switch (cellule.getType()) {
            case AMPOULE:
                pane.setStyle("-fx-background-color: yellow;");
                break;
            case ILLUMINEE:
                pane.setStyle("-fx-background-color: lightgrey;");
                break;
            case VIDE:
                pane.setStyle("-fx-background-color: white;");
                break;
            case MUR:
                int nombreAmpoulesNecessaires = cellule.getNombreAmpoulesNecessaires();
                int ampoulesAutour = compterAmpoulesAutour(x, y);
                if (ampoulesAutour == nombreAmpoulesNecessaires) {
                    pane.setStyle("-fx-background-color: grey;");
                } else {
                    pane.setStyle("-fx-background-color: red;");
                }
                return;
            default:
                break;
        }

        pane.addEventHandler(MouseEvent.MOUSE_CLICKED, event -> {
            if (event.getButton() == MouseButton.PRIMARY) {
                placerOuRetirerAmpoule(x, y, pane, event);
            } else if (event.getButton() == MouseButton.SECONDARY) {
                addFlag(pane, event);
            }
        });

        this.gridPane.add(pane, x, y);
    }

    // Recherche et renvoie le nœud situé à la colonne et à la ligne spécifiées dans le GridPane
    private Node getNodeFromGridPane(int col, int row) {
        for (Node node : this.gridPane.getChildren()) {
            Integer columnIndex = GridPane.getColumnIndex(node);
            Integer rowIndex = GridPane.getRowIndex(node);
            if (columnIndex != null && rowIndex != null && columnIndex == col && rowIndex == row) {
                return node;
            }   
        }
        return null;
    }

    // Met à jour les cellules de type murs
    private void mettreAJourMurs() {
        for (int x = 0; x < jeuAraki.getLargeur(); x++) {
            for (int y = 0; y < jeuAraki.getHauteur(); y++) {
                Cellule cellule = jeuAraki.getCellule(x, y);
                if (cellule.getType() == TypeCellule.MUR && cellule.getNombreAmpoulesNecessaires() != -1) {
                    Pane pane = (Pane) getNodeFromGridPane(x, y);
                    if (pane != null) {
                        updateCellPaneAppearance(x, y, pane);
                    }
                }
            }
        }
    }

    // Place ou retire une ampoule dans une cellule
    private void placerOuRetirerAmpoule(int x, int y, Pane pane, MouseEvent event) {
        if (jeuTermine) {
            return;
        }
        
        Cellule cellule = jeuAraki.getCellule(x, y);
        TypeCellule typeCellule = cellule.getType();

        if (typeCellule == TypeCellule.AMPOULE) {
            pane.setStyle("-fx-background-color: white;");
            jeuAraki.getCellule(x, y).setType(TypeCellule.VIDE);
            eteindreLumiere(x, y);
        } else if (typeCellule == TypeCellule.VIDE || (typeCellule == TypeCellule.MUR && cellule.getNombreAmpoulesNecessaires() == -1)) {
            pane.setStyle("-fx-background-color: yellow;");
            jeuAraki.getCellule(x, y).setType(TypeCellule.AMPOULE);
            propagerLumiere(x, y);
        }

        mettreAJourMurs();
        
        if (verifierConditionsVictoire()) {
            scoreTotal += 5;
            updateScoreLabel();
            showAlert("Bravo !", "Vous avez gagné !\n\nScore : " + scoreLabel.getText()+ "\n\nContinuer à jouer pour améliorer votre score.");
        }
    }

    // Propage la lumière autour d'une cellule
    private void propagerLumiere(int x, int y) {
        propagerDansDirection(x, y, 1, 0);
        propagerDansDirection(x, y, -1, 0);
        propagerDansDirection(x, y, 0, 1);
        propagerDansDirection(x, y, 0, -1);
    }

    // Propage la lumière dans une direction donnée
    private void propagerDansDirection(int x, int y, int dx, int dy) {
        int nx = x + dx;
        int ny = y + dy;
        while (nx >= 0 && nx < jeuAraki.getLargeur() && ny >= 0 && ny < jeuAraki.getHauteur()) {
            TypeCellule type = jeuAraki.getCellule(nx, ny).getType();
            if (type == TypeCellule.MUR) {
                break;
            }
            if (type == TypeCellule.VIDE) {
                jeuAraki.getCellule(nx, ny).setType(TypeCellule.ILLUMINEE);
                Pane pane = (Pane) getNodeFromGridPane(nx, ny);
                if (pane != null) {
                    pane.setStyle("-fx-background-color: lightgrey;");
                }
            }
            nx += dx;
            ny += dy;
        }
    }

    // Compte le nombre d'ampoules pour les cases numérotés
    private int compterAmpoulesAutour(int x, int y) {
        int count = 0;
        int[][] directions = {{-1, 0}, {1, 0}, {0, -1}, {0, 1}};
        for (int[] dir : directions) {
            int nx = x + dir[0];
            int ny = y + dir[1];
            if (nx >= 0 && nx < jeuAraki.getLargeur() && ny >= 0 && ny < jeuAraki.getHauteur()) {
                if (jeuAraki.getCellule(nx, ny).getType() == TypeCellule.AMPOULE) {
                    count++;
                }
            }
        }
        return count;
    }

    // Eteind lumière si on l'enlève
    private void eteindreLumiere(int x, int y) {
        eteindreDansDirection(x, y, 1, 0);
        eteindreDansDirection(x, y, -1, 0); 
        eteindreDansDirection(x, y, 0, 1); 
        eteindreDansDirection(x, y, 0, -1); 
        reEclairer();
    }

    // Eteindre lumière en fonction de la direction
    private void eteindreDansDirection(int x, int y, int dx, int dy) {
        int nx = x + dx;
        int ny = y + dy;
        while (nx >= 0 && nx < jeuAraki.getLargeur() && ny >= 0 && ny < jeuAraki.getHauteur()) {
            TypeCellule type = jeuAraki.getCellule(nx, ny).getType();
            if (type == TypeCellule.MUR) {
                break;
            }
            if (type == TypeCellule.ILLUMINEE) {
                jeuAraki.getCellule(nx, ny).setType(TypeCellule.VIDE);
                Pane cellPane = (Pane) getNodeFromGridPane(nx, ny);
                if (cellPane != null) {
                    cellPane.setStyle("-fx-background-color: white");
                }
            }
            nx += dx;
            ny += dy;
        }
    }

    // reEclaire si jamais une ampoule est repositionnée
    private void reEclairer() {
        for (int x = 0; x < jeuAraki.getLargeur(); x++) {
            for (int y = 0; y < jeuAraki.getHauteur(); y++) {
                if (jeuAraki.getCellule(x, y).getType() == TypeCellule.AMPOULE) {
                    propagerLumiere(x, y);
                }
            }
        }
    }

    // Balise pour aider l'utilisateur à jouer
    private void addFlag(Pane pane, MouseEvent event) {
        boolean containsSquare = false;
        for (Node node : pane.getChildren()) {
            if (node instanceof Rectangle) {
                containsSquare = true;
                break;
            }
        }
    
        if (containsSquare) {
            pane.getChildren().removeIf(node -> node instanceof Rectangle);
        } else {
            
            Rectangle square = new Rectangle(10, 10);
            square.setStrokeWidth(2);
            square.setStyle("-fx-background-color: black");
            square.translateXProperty().bind(pane.widthProperty().subtract(square.getWidth()).divide(2));
            square.translateYProperty().bind(pane.heightProperty().subtract(square.getHeight()).divide(2));
            pane.getChildren().add(square);
        }
    }

    // Vérifie les conditions victoires avant de mettre le message
    private boolean verifierConditionsVictoire(){
        for (int x = 0; x < jeuAraki.getLargeur(); x++){
            for (int y = 0; y < jeuAraki.getHauteur(); y++) {
                Cellule cellule = jeuAraki.getCellule(x, y);

                if (cellule.getType() == TypeCellule.VIDE) {
                    return false;
                }

                if  (cellule.getType() == TypeCellule.MUR && cellule.getNombreAmpoulesNecessaires() != -1) {
                    if (compterAmpoulesAutour(x, y) != cellule.getNombreAmpoulesNecessaires()) {
                        return false;
                    }
                }
            }
        }
        jouerSonVictoire();
        jeuTermine = true;
        return true;
    }

    // Joue le son victoire lorsque le joueur gagne
    private void jouerSonVictoire(){
        AudioClip audioClip = new AudioClip(getClass().getResource("/iut/prj2024/sound/victoire.wav").toExternalForm());
        audioClip.play();
    }
    
    // Montrer la boite de dialogue
    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    // Boite de dialogue pour pouvoir revenir au menu
    @FXML
    private void actionNvJeu() throws Exception{
        Alert confrimationAlert = new Alert(Alert.AlertType.CONFIRMATION);
        confrimationAlert.setTitle("Confirmation pour lancer une nouvelle grille");
        confrimationAlert.setHeaderText("Êtes-vous certain de vouloir lancer une nouvelle grille ?\n\nLe score n'est pas perdu :)");
        Optional<ButtonType> result = confrimationAlert.showAndWait();

        if (result.isPresent() && result.get() == ButtonType.OK) {
            jeuTermine = false;
            setMenuVisibility(true);
            setVBoxVisibility(true);
            setMenuVisibility(true);
            app.showLandingPage();
        }
    }

    // Mise à jour du score du joueur
    private void updateScoreLabel(){
        scoreLabel.setText(""+scoreTotal);
    }

    // Boite de dialogue pour quitter l'application
    @FXML
    private void actionQuitter(){
        Alert confirmationAlert = new Alert(Alert.AlertType.CONFIRMATION);
        confirmationAlert.setTitle("Confirmation pour quitter l'application");
        confirmationAlert.setHeaderText("Êtes-vous sûr de vouloir quitter ?\n\nVoici votre score : "+scoreLabel.getText());

        Optional<ButtonType> result = confirmationAlert.showAndWait();
        if (result.isPresent() && result.get() == ButtonType.OK) {
            fermerApplication();
        }
    }

    // Affichage du score avant la fermeture de l'application
    private void fermerApplication(){
        updateScoreLabel();
        Stage stage = (Stage) gameGrid.getScene().getWindow();
        stage.close();
    }

    
}
