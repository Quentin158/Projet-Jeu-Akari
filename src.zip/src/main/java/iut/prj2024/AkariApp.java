package iut.prj2024; 


import java.io.IOException;

import iut.prj2024.view.AkariAppController;
import javafx.application.Application;

import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;

import javafx.scene.layout.BorderPane;

import javafx.stage.Stage;

public class AkariApp extends Application {

    private Stage primaryStage;
    private BorderPane root;

    // Méthode principale de l'application JavaFX
	public void start(Stage primaryStage) throws Exception {
        this.primaryStage = primaryStage;
        this.root = new BorderPane();
        
        Scene scene = new Scene(root);
        primaryStage.setScene(scene);
        
        primaryStage.setTitle("Projet Akari | MARTINEZ Quentin 3B");
        showLandingPage();
        primaryStage.show();
    }

    // Méthode pour démarrer l'application
    public static void main2(String[] args) {
        Application.launch(args);
    }

    // Méthode pour afficher la page d'accueil de l'application
    public void showLandingPage() throws Exception{
        try {
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(AkariApp.class.getResource("view/LandingPage.fxml"));
            BorderPane vueLandingPage = loader.load();

            AkariAppController controller = loader.getController();
            controller.setApp(this);

            this.root.setCenter(vueLandingPage);
        } catch (IOException e) {
            e.printStackTrace();
            System.out.println("FXML pas trouvé");
            System.exit(1);
        }
    }
}